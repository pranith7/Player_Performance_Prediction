from setuptools import setup

setup(
    name="cricinfo",
    version="0.1",
    packages=["cricinfo"],
    install_requires=[
        # List your library's dependencies here
        
    ],
)
